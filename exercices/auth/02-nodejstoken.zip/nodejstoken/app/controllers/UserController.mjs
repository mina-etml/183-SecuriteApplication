export const get = (req, res) => {
    res.send("User: Sarah");
};